#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char const *argv[])
{
    int i;
    char *arr[31];
    //initially 3 pages allocated by default in allocuvm
    for (i = 0; i < 12; ++i) {
		arr[i] = sbrk(4096);
		printf(1, "arr[%d]=0x%x\n", i, arr[i]);
	}
	printf(1, "Called sbrk(PGSIZE) 12 times - all physical pages taken.\n");
    arr[12] = sbrk(4096);
	printf(1, "arr[12]=0x%x\n", arr[12]);
	printf(1, "Called sbrk(PGSIZE) for the 13th time, a page fault should occur and one page in swap file.\n");
	
	int j;
    for (i = 0; i < 5; i++) {
		for (j = 0; j < 4096; j++)
			arr[i][j] = 'b';
	}
    for (i = 0; i < 14; ++i) {
		arr[i] = sbrk(4096);
		printf(1, "arr[%d]=0x%x\n", i, arr[i]);
	}
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 4096*2; j++)
			arr[i][j] = 'b';
	}
    printf(1, " Starting dealloc tests ...\n");
    // Testing dealloc
    for (i = 0; i < 14; ++i) {
		arr[i] = sbrk(-4096);
		printf(1, "arr[%d]=0x%x\n", i, arr[i]);
	}
    exit();
}
