package Server;

public class NetworkAddress {
    String ipAddress;
    int port;

    NetworkAddress(String ipAddress, int port){
        this.ipAddress = ipAddress;
        this.port = port;
    }
}